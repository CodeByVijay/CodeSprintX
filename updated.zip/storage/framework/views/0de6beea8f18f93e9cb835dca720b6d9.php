
<?php /**PATH /var/www/html/codesprintx/resources/views/home/pages/course_description_scripts_fixed.blade.php ENDPATH**/ ?>